# Awesome MIMIC-CXR [![Awesome](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)](https://github.com/sindresorhus/awesome)

A curated list of MIMIC-CXR resources.

## Contributing

Please feel free to send in [pull requests](https://github.com/mit-lcp/mimic-cxr/pulls) to add links.

## Table of Contents

<!--
 - [Books](#books)
 - [Courses](#courses)
 - [Tutorials and Talks](#tutorials-and-talks)
 - [Resources for students](#resources-for-students)
 - [Blogs](#blogs)
 - [Links](#links)
-->

 - [Papers](#papers)
 - [Software](#software)
 - [Datasets](#datasets)

 ## Papers

 ## Software

 ## Datasets