# MIMIC-CXR

MIMIC-CXR is a publicly available database of chest x-rays with free-text radiology reports. You can read more about the dataset on [the PhysioNet project page](https://mimic.mit.edu//iv/modules/cxr/about/).

This repository is intended to support use of the data by providing code, documentation, and a central location for discussion (in the form of GitHub issues). Feedback and contributions are always welcome!