# Scripts for demographics

This directory contains scripts that can be used to create tables and views related to demographics. 

The ICUSTAY_DETAILS combines information from the admissions, patients, and icustays tables. It includes age, length of stay, sequence, and expiry flags.