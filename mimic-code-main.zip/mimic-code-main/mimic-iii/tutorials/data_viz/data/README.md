# MIMIC-III data goes in this folder

The tutorials load data from the `data` subfolder. In order to run them copy MIMIC-III data into this folder (or symlink appropriately). The following files are needed:

* ADMISSIONS.csv
* CPTEVENTS.csv
* D_LABITEMS.csv
* LABEVENTS.csv
* PATIENTS.csv
* PRESCRIPTIONS.csv